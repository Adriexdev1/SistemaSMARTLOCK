const { Client, LocalAuth, MessageMedia } = require("whatsapp-web.js");
const qrcode = require("qrcode-terminal");
const QRCode = require("qrcode");
const sql = require("mssql");

// 🔧 Configuración de base de datos
const dbConfig = {
    server: "SMARTLOCK_BD.mssql.somee.com",
    database: "SMARTLOCK_BD",
    user: "adrielh74_SQLLogin_2",
    password: "h8nti37qgl",
    options: { encrypt: true, trustServerCertificate: true }
};

const client = new Client({
    authStrategy: new LocalAuth(),
    puppeteer: { headless: true, args: ['--no-sandbox', '--disable-setuid-sandbox'] }
});

const userSessions = new Map();

// =========================================================
// INICIO DEL BOT
// =========================================================
client.on("qr", qr => {
    console.log("📱 Escanea este QR para iniciar el bot:");
    qrcode.generate(qr, { small: true });
});

client.on("ready", () => console.log("✅ Bot de Citas Dentales conectado a WhatsApp!"));

client.on("message", async msg => {
    const phone = msg.from;
    const message = msg.body.trim();
    if (!userSessions.has(phone)) {
        userSessions.set(phone, { step: "menu_principal", data: {}, lastActivity: new Date() });
        await msg.reply("👋 ¡Hola! Bienvenido al *Consultorio Dental SmartLock* 🦷\n\nElige una opción:\n1️⃣ *Agendar cita*\n2️⃣ *Cancelar citas*\n\nEscribe el número de tu opción:");
        return;
    }

    const session = userSessions.get(phone);
    session.lastActivity = new Date();

    try {
        await handleConversation(msg, session, message);
    } catch (err) {
        console.error("Error:", err);
        await msg.reply("❌ Ocurrió un error. Intenta más tarde.");
    }
});

// =========================================================
// MANEJO DE CONVERSACIÓN
// =========================================================
async function handleConversation(msg, session, message) {
    switch (session.step) {
        // ===== MENÚ PRINCIPAL =====
        case "menu_principal":
            if (message === "1") {
                session.step = "tiene_cuenta";
                await msg.reply("🦷 ¿Ya tienes una cuenta registrada con tu correo electrónico? (responde *sí* o *no*)");
            } else if (message === "2") {
                session.step = "cancelar_correo";
                await msg.reply("🗑️ Escribe el *correo electrónico* con el que hiciste la cita que deseas cancelar:");
            } else {
                await msg.reply("❌ Opción no válida. Escribe *1* para agendar o *2* para cancelar una cita.");
            }
            break;

        // ===== AGENDAR CITA =====
        case "tiene_cuenta":
            if (["si", "sí"].includes(message.toLowerCase())) {
                session.step = "correo_existente";
                await msg.reply("📧 Por favor, escribe tu *correo electrónico* registrado:");
            } else {
                session.step = "nombre";
                await msg.reply("Perfecto 🦷. Empecemos tu registro.\nPor favor, dime tu *nombre completo*:");
            }
            break;

        case "correo_existente":
            session.data.correo = message;
            const usuarioExistente = await obtenerUsuarioPorCorreo(message);
            if (!usuarioExistente) {
                await msg.reply("❌ No encontramos una cuenta con ese correo. Escribe *no* para crear una nueva o vuelve a intentarlo:");
                session.step = "tiene_cuenta";
                return;
            }
            session.data.id_usuario = usuarioExistente.id_usuario;
            session.data.nombre = usuarioExistente.nombre_usuario;
            session.step = "motivo";
            await msg.reply(`✅ Hola ${usuarioExistente.nombre_usuario}.\n¿Cuál es el *motivo de tu cita*?`);
            break;

        case "nombre":
            session.data.nombre = message;
            session.step = "telefono";
            await msg.reply("📱 Ahora, envíame tu *número de teléfono*:");
            break;

        case "telefono":
            session.data.telefono = message;
            session.step = "correo";
            await msg.reply("📧 Escribe tu *correo electrónico*:");
            break;

        case "correo":
            session.data.correo = message;
            session.step = "nacimiento";
            await msg.reply("🎂 Indica tu *fecha de nacimiento* (YYYY-MM-DD):");
            break;

        case "nacimiento":
            session.data.nacimiento = message;
            const idUsuario = await registrarUsuario(session.data);
            if (!idUsuario) {
                await msg.reply("⚠️ No se pudo registrar el usuario. Verifica que exista el rol 'Paciente' activo.");
                userSessions.delete(msg.from);
                return;
            }
            session.data.id_usuario = idUsuario;
            session.step = "motivo";
            await msg.reply("✅ Usuario registrado.\n¿Cuál es el *motivo de tu cita*?");
            break;

        case "motivo":
            session.data.motivo = message;
            session.step = "fecha";
            await msg.reply("🗓️ ¿Qué *día* deseas tu cita? (formato: YYYY-MM-DD)");
            break;

        case "fecha":
            session.data.fecha = message;
            session.step = "hora";
            await msg.reply("🕒 ¿A qué *hora* prefieres? (formato 24h, ejemplo: 15:00)");
            break;

        case "hora":
            const [year, month, day] = session.data.fecha.split("-");
            const [hour, minute] = message.split(":");
            let fechaInicio = new Date(year, month - 1, day, hour, minute);

            fechaInicio = new Date(fechaInicio.getTime() - (6 * 60 * 60 * 1000));
            const fechaFin = new Date(fechaInicio.getTime() + 60 * 60 * 1000); // +1 hora

            const disponible = await verificarDisponibilidad(fechaInicio, fechaFin);
            if (!disponible) {
                await msg.reply("❌ Esa hora no está disponible. Por favor, elige otra.");
                return;
            }

            const idEvento = await registrarEvento(session.data, fechaInicio, fechaFin);
            const idDetalle = await registrarDetalle(session.data.id_usuario, idEvento);

            // Generar QR
            const qrUrl = `http://smartlockone.somee.com/puerta.aspx?id=${idDetalle}&token=ABC123`;
            const qrDataURL = await QRCode.toDataURL(qrUrl);
            const base64Data = qrDataURL.replace(/^data:image\/png;base64,/, "");
            const media = new MessageMedia("image/png", base64Data, "cita_qr.png");

            await msg.reply(media);
            await msg.reply(`✅ *Cita confirmada* 🦷
📅 Fecha: ${session.data.fecha}
🕒 Hora: ${message}
📋 Motivo: ${session.data.motivo}
🔗 ID Detalle: ${idDetalle}

Escanea el QR para confirmar tu asistencia.
\nEscribe *menu* si deseas regresar al inicio.`);

            userSessions.delete(msg.from);
            break;

        // ===== CANCELAR CITA =====
        case "cancelar_correo":
            session.data.correo = message;
            const usuario = await obtenerUsuarioPorCorreo(message);
            if (!usuario) {
                await msg.reply("❌ No se encontró ningún usuario con ese correo.");
                userSessions.delete(msg.from);
                return;
            }

            const canceladas = await cancelarCitas(usuario.id_usuario);
            if (canceladas > 0) {
                await msg.reply(`✅ Se cancelaron ${canceladas} cita(s) activas asociadas al correo *${message}*.`);
            } else {
                await msg.reply("ℹ️ No hay citas activas para cancelar.");
            }
            userSessions.delete(msg.from);
            break;
    }
}

// =========================================================
// FUNCIONES DE BASE DE DATOS
// =========================================================

async function obtenerUsuarioPorCorreo(correo) {
    await sql.connect(dbConfig);
    const result = await sql.query`SELECT TOP 1 id_usuario, nombre_usuario FROM usuarios WHERE correo_usuario = ${correo}`;
    return result.recordset[0];
}

async function registrarUsuario(datos) {
    await sql.connect(dbConfig);

    // Verificar si existe rol "Paciente" activo
    const rol = await sql.query`SELECT id_rol FROM roles WHERE nombre_rol = 'Paciente' AND estado_rol = 1`;
    if (rol.recordset.length === 0) return null;

    const idRol = rol.recordset[0].id_rol;

    const insert = await sql.query`
        INSERT INTO usuarios (nombre_usuario, telefono_usuario, correo_usuario, id_rol, estado_usuario, fecha_usuario, nacimiento_usuario)
        OUTPUT INSERTED.id_usuario
        VALUES (${datos.nombre}, ${datos.telefono}, ${datos.correo}, ${idRol}, 1, GETDATE(), ${datos.nacimiento});
    `;
    return insert.recordset[0].id_usuario;
}

async function verificarDisponibilidad(inicio, fin) {
    await sql.connect(dbConfig);
    const result = await sql.query`
        SELECT COUNT(*) AS total FROM eventos
        WHERE estado_evento = 1
        AND (
            (fechaprogramada_evento <= ${inicio} AND fechalimite_evento > ${inicio})
            OR (fechaprogramada_evento < ${fin} AND fechalimite_evento >= ${fin})
        );
    `;
    return result.recordset[0].total === 0;
}

async function registrarEvento(datos, inicio, fin) {
    const insert = await sql.query`
        INSERT INTO eventos (nombre_evento, descripcion_evento, fechaprogramada_evento, fechalimite_evento, estado_evento, fecha_evento)
        OUTPUT INSERTED.id_evento
        VALUES ('Cita Dental', ${datos.motivo}, ${inicio}, ${fin}, 1, GETDATE());
    `;
    return insert.recordset[0].id_evento;
}

async function registrarDetalle(idUsuario, idEvento) {
    const insert = await sql.query`
        INSERT INTO detalle_eventos (id_usuario, id_evento, fecha_detalle_evento, rol_en_evento)
        OUTPUT INSERTED.id_detalle_evento
        VALUES (${idUsuario}, ${idEvento}, GETDATE(), 'Paciente');
    `;
    return insert.recordset[0].id_detalle_evento;
}

async function cancelarCitas(idUsuario) {
    await sql.connect(dbConfig);
    const result = await sql.query`
        UPDATE eventos
        SET estado_evento = 0
        WHERE id_evento IN (SELECT id_evento FROM detalle_eventos WHERE id_usuario = ${idUsuario})
        AND estado_evento = 1;
        SELECT @@ROWCOUNT AS canceladas;
    `;
    return result.recordset[0].canceladas;
}

client.initialize();
